<?php

// Heading
$_['heading_title']  = 'Aviso de política de cookies simples';

// Content
$_['consent_text']   = 'Ao continuar a sua visita a este site, você concorda com o uso de cookies';
$_['consent_button'] = 'Entendi';